# Hayool OS — بسته نهایی حقیقت مرجع پیش از کدنویسی

نسخهٔ ۷.۱، ۲۵ سپتامبر ۲۰۲۶. این بسته نتیجهٔ مطالعهٔ کامل ۶۱ فایل V6 و V7 و اجرای بخش طراحی دستور اصلی `V7/10_CHATGPT_WORK_MASTER_BUILD_PROMPT.md` در چارچوب دستور فعلی مالک است: در مرحلهٔ اول هیچ کد محصولی نوشته نشده است. نسخه‌های خام منابع در `archive/sources/` بدون تغییر نگهداری می‌شوند. مبنای طراحی، `docs/SOURCE_OF_TRUTH_INDEX.md` و حل تعارض‌های `docs/CONFLICT_RESOLUTIONS.md` است؛ کاتالوگ‌ها و قراردادهای تخصصی به آن متصل‌اند. ادعای پیاده‌سازی، تأیید قانون یا آمادگی بازار در این بسته وجود ندارد.

## تحویل‌ها و مسیر مطالعه

| خواسته | سند اصلی |
|---|---|
| بستهٔ نهایی حقیقت مرجع و منشأ منابع | `docs/SOURCE_OF_TRUTH_INDEX.md`, `SOURCE_MANIFEST.json`, `docs/requirements/SOURCE_COVERAGE.md`, `PACKAGE_MANIFEST.json` |
| معماری نهایی و قراردادهای دامنه | `docs/architecture/FINAL_ARCHITECTURE.md`, `DOMAIN_CONTRACTS.md` |
| کاتالوگ کامل نیازمندی‌ها و ADR | `docs/requirements/REQUIREMENTS_CATALOG.md`, `docs/adr/ADR_CATALOG.md` |
| نقشهٔ راه M0 تا V1.10 و بعد | `docs/releases/RELEASE_ROADMAP.md` |
| آزمون و شواهد | `docs/testing/TESTING_STRATEGY.md`, `docs/evidence/EVIDENCE_INDEX.md` |
| توسعه/رفع خطا/به‌روزرسانی خودکار | `docs/engineering/AUTONOMOUS_ENGINEERING_PLAN.md` |
| کشورها، حوزه‌های قضایی و تأمین‌کنندگان | `docs/country-packs/GLOBAL_JURISDICTION_ARCHITECTURE.md` |
| امنیت، حریم خصوصی و انطباق | `docs/security/SECURITY_PRIVACY_COMPLIANCE.md` |
| مالی و مدل کسب‌وکار | `docs/finance/FINANCIAL_BUSINESS_REQUIREMENTS.md` |
| Studio/Developer/Marketplace | `docs/platform/DEVELOPER_STUDIO_MARKETPLACE_ARCHITECTURE.md` |
| وضعیت، اقدام‌های بعدی و تصمیم مالک | `PROJECT_STATE.md`, `NEXT_ACTIONS.md`, `docs/OWNER_DECISIONS.md` |

تمام قابلیت‌های مهم V6، از جریان پروژه و مالی و نیروی انسانی تا CMS/eCommerce، تولید و زنجیرهٔ تأمین، در قراردادهای نیازمندی/دامنه حفظ شده‌اند. V1 مجموعهٔ V1.0 تا V1.10 است، نه نسخهٔ نخست آن. معماری بسته‌های Country/Subnational و Registry برای همهٔ کشورها تعریف شده اما فعال‌سازی هر قابلیت و هر مسیر پرداخت/AI نیازمند شواهد و تأیید جداگانه است. پیش‌فرض ایران محدود به استعداد داخلی واجد شرایط و راستی‌آزمایی‌شده است؛ برای دیگر کشورها حالت domestic، regional یا global تنها با policy مصوب و محدودیت‌های مربوط اجرا می‌شود.

بازبینی مستقل طراحی M0.1 با digest ثبت‌شده در `docs/evidence/DOCUMENT_REVIEW.md` بسته شده است؛ M0.0 و M0.2، و هر ادعای آزمون یا انتشار محصول، هنوز انجام نشده‌اند. تصمیم فنی بازگشت‌پذیر در ADR ثبت شده است. تنها انتقال به مرحلهٔ کدنویسی اکنون به لغو دستور «اول هیچ کدی ننویس» و تعیین مخزن/مقصد نیاز دارد. فهرست تصمیم‌های حقوقی، مالی و تجاری برای مراحل فعال‌سازی آینده در `docs/OWNER_DECISIONS.md` آمده است.
