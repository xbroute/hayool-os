# Complete testing and evidence strategy

All tests below are specified, not executed product tests. Each REQ has the stable planned contract `TEST-<REQ-ID>` (for example `TEST-REQ-FIN-005`), with its proof oracle and suite in the REQ catalog/JSON mirror. Implementation decomposes that contract into positive, negative, concurrency and failure cases where applicable; an empty evidence record cannot pass.

## Test layers and oracles

Domain unit/property tests for deterministic rules; integration against actual PostgreSQL/runtime RLS role and workflow/cache/blob adapters; provider contract tests against fakes then provider sandbox; browser E2E on isolated staging; manual accessibility and independent security/finance/legal review; restore/upgrade and real internal/design-partner outcome proof. Critical oracle derives from approved REQ and independent fixture, not copied implementation. Golden expected money/eligibility values independently reviewed. Synthetic cases never substitute for market/legal evidence.

| Suite | Required cases | Pass oracle | Evidence |
|---|---|---|---|
| TEN | API/FK/cache/jobs/files/search/facets/RAG/websocket/export/restore A vs B | zero unauthorized result or existence leak, writes unchanged | runtime-role reports and denied audit refs |
| AUTH | role/entity/field/app/revocation/delegation/support grant | unauthorized side effects zero; installer privilege never inherited | permission matrix execution |
| FIN | balance/rounding/FX/period lock/reversal/idempotency/partial payment/refund/chargeback | exact independent totals; closed/posted immutable | fixtures + journal/reconciliation output |
| PAY | duplicate/reordered/spoofed callback/timeout/unknown result/concurrency | no duplicate charge/posting; unknown queued | sandbox attempt and settlement trace |
| POL | domestic/global/missing/conflict/expired/subnational/revoked/queued policy | eligibility before pool; no pending side effect | context+rule+decision snapshots |
| AI | AI-off/injection/ACL/cost race/unknown model/fallback/eval drift | deterministic authority intact, caps preserved | eval versions/usage ledger |
| WORK | scope change/time overlap/capacity race/acceptance/commission reversal/SLA clock | approved inputs only; dependency/state integrity | golden loop trace |
| EXT | install/scope expansion/egress/uninstall/upgrade/signature/abandonment | no Core patch or unauthorized data, version survival | 3 app dossiers |
| DATA | import dry-run/duplicates/mapping/export/retention/hold/deletion restore | reconciliation complete; erased data not resurrected | import and rights job reports |
| OPS | crash after commit/queue restart/network loss/recovery/migration | recoverable states and measured RTO/RPO | backup restore + upgrade logs |
| PHYS | stock race/lot recall/offline replay/partial shipment/compensation | quantities/valuation conserved, no unsafe OT effect | movement and saga traces |
| UX | fa-IR/en/keyboard/screen reader/zoom/mobile/error/offline | all critical outcomes operable with zero blockers | automated reports + human protocol |
| PERF | declared dataset/concurrency/hardware/long export/noisy tenant | target latency and bounded resource use | p50/p95/p99, error/CPU/DB reports |
| AUTO | stale SHA/writer/test weakening/injection/caps/kill switch | every seeded blocker halts | ENG-RUN audit + shadow comparison |

## Required golden scenarios

GJ-01A (V1.0) Client intake -> approved scope -> independently reproducible quote -> contract -> feasible team -> tracked and accepted effort -> delivered/accepted work -> partial invoice collection -> reconciled project contribution. Run Persian and English roles, disabled external AI, rejected permissions, duplicate payment, scope change, provider outage and refund variant. Actual internal project required for V1.0, synthetic rehearsals before live operation. GJ-01B (V1.1) extends the same preserved client/project trace through attributed commission/refund clawback, support ticket/SLA escalation, customer health and portal acceptance. Neither variant grants external AI use before first-use governance.

GJ-02 second company installs/onboards/imports/uses/exports/upgrades without engineers repairing data. GJ-03 Iran domestic and synthetic multi-jurisdiction eligible talent lifecycle including unknown/ineligible and appeal. GJ-04 Studio repair app + remote supplier extension + re-consent + upgrade + export/uninstall. GJ-05 procurement -> receipt/lot -> reserve -> ship -> return/refund -> inventory/finance reconciliation. GJ-06 backup loss simulation -> compatible restore -> privacy tombstones -> payment reconciliation -> reopen.

## Fixtures, determinism and failure injection

At least tenants A/B, entity A1/A2, client/talent/developer/service actors, revoked membership, secret sentinel, IRR/Toman and 0/2/3 minor-unit synthetic currencies, DST gap/fold and Jalali presentation, two approved and one expired policy, healthy-but-ineligible provider, deterministic clock/seed. Scrubbed synthetic data only in CI. Inject process death before/after DB commit, duplicate event, timeout after external acceptance, partial provider failure, dead-letter, stale policy and storage interruption. Time windows are simulated, no long sleeps.

Property-based tests cover ledger balance, bounded refund/credit use, dimensional units, idempotent replay, scope monotonicity and inventory conservation. Fuzz parsers/uploads/expressions/policy schemas/webhooks. Critical regression oracle changes require separate independent review. Flaky test quarantine is visible with owner/expiry and replacement evidence; a required blocker test cannot be simply skipped for release.

## CI selection and blocking policy

Every PR: trace/schema/docs checks, relevant unit/type/lint/build/secrets. Critical paths: full finance/tenant/auth/policy suites and specialist review. Public contracts: compatibility/SDK/sample apps. Significant UI: staging browser RTL/LTR/accessibility. Release: all required suites, migration/restore/upgrade/provenance/SBOM/licenses, accepted residual risks and current country/provider evidence. A missing check is pending; deterministic fail outranks model consensus. Test results bind exact SHA/build/policy/fixture/tool version. Nightly breadth adds robustness but cannot repair a failed merge gate by scheduling it later.

## Acceptance and coverage policy

100% REQ-to-test-contract linkage required; behavioral code coverage numeric target is diagnostic, not correctness proof. Critical invariants must all have positive/negative/concurrency/failure cases; changed finance/auth/tenancy branches require meaningful coverage review. No arbitrary '95% coverage therefore safe' claim. All milestone-mandatory acceptance tests pass; zero known P0/P1; documented evidence supports every readiness dimension. Performance/a11y/manual/legal evidence separately recorded, not inferred from unit tests.

## Evidence envelope

EVID-ID, REQ/test IDs, exact SHA/release/build digest, environment/data profile, policy/provider/pack versions, timestamp, tool version, command/procedure, expected/actual, result, artifact hash/location, reviewer identity, limitations, expiry and revalidation trigger. Protect reports against overwrite and sensitive disclosure. A markdown description of a future test stays PLANNED. Formal gate report lists executed/not-executed/blockers separately.
