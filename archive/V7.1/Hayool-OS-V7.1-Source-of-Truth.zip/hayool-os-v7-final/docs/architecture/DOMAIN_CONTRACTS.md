# Domain behavior and state contracts

Every command follows FINAL_ARCHITECTURE envelope/auth/idempotency. Every state transition records actor, reason, timestamps, policy and original fact references. Soft-delete cannot erase a posted fact. Source domain details remain normative.

| Domain | State / authority | Invariant | Failure / recovery | Outcome proof |
|---|---|---|---|---|
| Client discovery | draft -> reviewed requirements -> approved scope | assumptions distinct from approved requirements; versioned acceptance | conflicting client input creates change proposal | accepted scope links every deliverable |
| Quotes/contracts | draft -> priced -> approved -> offered -> accepted/expired/rejected | frozen price/rule/currency; amendments preserve old terms | signature/provider ambiguity remains pending | accepted proposal reproduces commercial terms |
| Project/work | proposed -> scoped -> planned -> assigned -> active -> review -> accepted -> closed | dependency DAG; acceptance authority separate from assignee where configured | reopen creates audited revision | accepted deliverable traces to REQ and client evidence |
| Time | draft -> submitted -> approved/rejected -> locked | tracked != accepted != billable != payable | overlapping/timezone errors flagged; correction adjustment after lock | payroll/invoice consumes only approved quantities |
| Capacity | available -> reserved -> committed -> released | no atomic over-reservation; leave/calendar/timezone policy | competing reservation loser refreshes | feasible team plan; infeasibility explained |
| Risk/OKR/KPI | identified -> assessed -> mitigated/accepted -> monitored -> closed | risk owner/trigger; metrics versioned, no invented success | stale evidence flagged | outcome improvement based on governed metric |
| Meeting | scheduled -> consented -> recorded/transcribed -> draft actions -> approved | recording policy applies to all processors and artifacts | no consent => manual notes; low confidence review | task has source time-span and approver |
| Ticket/SLA | new -> triaged -> assigned -> waiting -> resolved -> reopened/closed | business-hours clock, pause reasons/version; escalation | provider outage does not lose timer | timed breach raises auditable escalation |
| Health | facts -> dimensional calculation -> review -> action | payment/support/renewal/project components visible | stale inputs label stale, never confident green | health action links observed evidence |
| Commission | accrued -> eligible -> approved -> paid -> clawback adjustment | collection/refund/rule version linked; no double commission | refund after payout creates liability adjustment | attribution reconciles collections and payouts |
| Finance | draft -> validated -> posted -> reversed/adjusted | balanced per book/entity, immutable posted lines, closed period locked | posting atomic; duplicate source event no-op | trial balance and project margin reconcile |
| Payments | created -> authorized -> submitted -> pending -> confirmed/failed/unknown -> reconciled | provider auth and amount/currency match; no duplicate attempt | unknown forbids blind resubmission; reconciliation queue | duplicate/out-of-order/partial refund preserved |
| Payroll | draft -> calculated -> reviewed -> approved -> posted -> paid | rule snapshot; no automatic payment from timer | invalid country rule blocks finalization | reproducible run, approver and ledger match |
| Engagement | proposed -> eligible -> contracted -> active -> ended/disputed | explicit employer/payer/IP/tax/insurance obligations | unsupported mode remains blocked | approved mode completes work and settlement |
| Talent | private -> verified fields -> consented projection -> eligible -> ranked | eligibility before discovery/ranking; purpose-limited evidence | withdrawal removes network visibility promptly | eligible new talent receives bounded fair exposure |
| Inventory | receive/reserve/pick/ship/transfer/consume/produce/adjust/return/scrap | movement ledger, atomic reservation; policy-defined negative stock default off | stale availability => provider confirm; compensating movement | physical quantity and valuation reconcile |
| Fulfillment | draft -> quoted -> authorized -> confirmed -> partial/completed -> accepted -> settled | node-specific authority, reversibility, dependencies and costs | supplier committed/courier failed => alternate or cancel/refund/escalate | no orphan paid commitment without explicit recovery |
| Asset/EAM | registered -> assigned -> maintained -> retired | owner/warranty/access separate from secret | expired credential blocks capability, not read-only register | maintenance/renewal avoids undocumented dependency |
| CMS/site | draft -> review -> approved -> scheduled -> published -> archived | verified domain, safe blocks, separate public projection | failed build retains last valid publish | lead -> CRM and order -> fulfillment trace |
| Studio/app | draft -> validate -> simulate -> approve -> publish -> observe | schema/consent/version bound; cannot bypass protected commands | metadata rollback or forward repair preserves valid data | no-core-change solution survives upgrade |
| License | trial/active -> grace -> restricted/read-only -> renewed | expiry does not destroy or prevent lawful export | offline signed license with explicit grace policy | predictable access and recoverable renewal |
| Incident | detected -> triaged -> contained -> recovered -> reviewed | preserve evidence; notification governed by applicability | independent recovery identity | restored service plus regression/postmortem |

## Canonical value types

Money: decimal string amount, currency identifier, currency exponent metadata, functional currency, rule snapshot. API never accepts binary floating point as authoritative amount. Toman presentation uses explicit unit and deterministic 10 IRR conversion; storage/contract explicitly labels IRR. Quantity: decimal string plus UOM; dimensional conversions only. Instant: UTC timestamp; local date is separate civil date with calendar/timezone, never converted to midnight UTC without semantics. Effective intervals are half-open [from,to); rule history is append-only with recorded-at as well as effective-at.

## Common capability contract

Input schema/version, owning module, authorization action, tenant/entity scope, field-level scopes, policy context facts, validation, concurrency, idempotency retention, audit event, public event, sensitive data class, error codes, retry/compensation, observability, acceptance scenario and retention must be specified before a task enters implementation. Schema changes are additive first. A task missing these fields is NOT_READY rather than agent-invented behavior.

Error classes: VALIDATION, NOT_FOUND_OR_NOT_VISIBLE, CONFLICT, POLICY_DENIED, POLICY_PENDING, PROVIDER_UNAVAILABLE, OUTCOME_UNKNOWN, QUOTA_EXCEEDED, UNSUPPORTED_VERSION. Include safe message/action/correlation, not secrets/internal stack traces. Policy pending UI identifies missing user-suppliable facts without exposing restricted screening internals.
