# Hayool OS — Final Pre-code Source of Truth

Version 7.1 • rebaseline 2026-09-25 (source snapshot 2026-09-22) • Scope: design baseline, not an implementation or launch approval.

## Authority

The owner's current instruction authorizes this documentation rebaseline and prohibits product coding in this phase. Within that scope: (1) current explicit owner instruction and separately approved owner decisions, (2) engineering Constitution and Guardrails for safety, (3) this index and `CONFLICT_RESOLUTIONS.md`, (4) final architecture/contracts and REQ/ADR catalogs, (5) adopted domain details. A proposed owner default is not an approved decision. An unresolved conflict stops only the affected action. No document can authorize a legal exception, spending, production deployment or bypass of a hard gate.

V7.1 is the current design baseline. Original V6/V7 are immutable provenance in `archive/sources/`; adopted details in `docs/product`, `platform`, `domains`, `data`, `ai`, `compliance`, and `engineering` remain normative except the explicit resolutions. Their inherited vendor, regulatory, release-version and competitor assertions are historical research candidates. They are not current evidence or activation authorization.

V1 means the entire V1.0–V1.10 release family. It never means all capabilities ship at V1.0. Every major capability retains a contract now and a release/proof target. Beyond-V1 capabilities are retained explicitly, not silently removed.

## Read order

1. `../README_FA.md`, `../PROJECT_STATE.md`, `../NEXT_ACTIONS.md`.
2. This file and `CONFLICT_RESOLUTIONS.md`.
3. `engineering/AI_ENGINEERING_CONSTITUTION.md`, `engineering/ENGINEERING_GUARDRAILS.md`.
4. `architecture/FINAL_ARCHITECTURE.md`, `architecture/DOMAIN_CONTRACTS.md`.
5. `requirements/REQUIREMENTS_CATALOG.md`, `adr/ADR_CATALOG.md`.
6. `releases/RELEASE_ROADMAP.md`, `testing/TESTING_STRATEGY.md`.
7. `engineering/AUTONOMOUS_ENGINEERING_PLAN.md`.
8. `country-packs/GLOBAL_JURISDICTION_ARCHITECTURE.md`.
9. `security/SECURITY_PRIVACY_COMPLIANCE.md`, `finance/FINANCIAL_BUSINESS_REQUIREMENTS.md`.
10. `platform/DEVELOPER_STUDIO_MARKETPLACE_ARCHITECTURE.md`, `ai/AI_DATA_OUTCOME_ARCHITECTURE.md`, `ux/ACCESSIBILITY_DESIGN_SYSTEM.md`, `operations/DEPLOYMENT_RECOVERY.md`.
11. Relevant adopted detail; `evidence/EVIDENCE_INDEX.md`, `OWNER_DECISIONS.md`, `RISK_REGISTER.md`.

## Definitive objects

REQ catalog is the normative delivery catalog; JSON is its machine-readable mirror, generated from the same records. Acceptance obligations compose: specific REQ + source sections + shared test/security/accessibility contract. Source text is not discarded merely because an abbreviated catalog row omits a detail. `requirements/SOURCE_COVERAGE.md` maps every source section to retained requirement families and explicit exceptions. ADR catalog owns engineering decisions, not commercial approval. Roadmap owns release sequence, not a feature deletion.

`SOURCE_MANIFEST.json` inventories all 61 source files. `PACKAGE_MANIFEST.json` binds delivered files to hashes. A snapshot hash review is a document review, not an exact-commit Git/CI gate. Formal M0.2 must be repeated on the imported repository SHA.

## Readiness vocabulary

specified / designed / implemented / unit-tested / integration-tested / security-reviewed / accessibility-reviewed / staging-verified / jurisdiction-verified / market-validated / production-ready / deployed are independent fields. Null means not observed, never pass. No global 9.5 score is assigned to an unbuilt product. Evidence expires on relevant code, policy, provider, jurisdiction or assumption change.
