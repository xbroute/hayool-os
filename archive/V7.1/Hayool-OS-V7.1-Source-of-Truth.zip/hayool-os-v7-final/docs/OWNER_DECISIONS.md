# Owner decisions and activation holds

2026-09-25. `OD-001–030` in the adopted V6 owner sheet are proposed working defaults, not signatures. This document does not change them. The current owner instruction explicitly sets the no-product-code first phase, final V7 design, all-country pack architecture, Iran domestic-only default and outcomes as milestones. Everything else below remains unapproved. The engineering ADR catalog settles reversible technical choices. A jurisdiction policy requires qualified legal/accounting advice as applicable; this list asks the owner for business authorization, not for the owner to act as counsel.

## Exactly what is needed before product coding

The first phase is documentation-only. To begin a later implementation phase, the owner must explicitly lift that instruction and supply or authorize the target project repository/workspace destination and access. We have not discovered a Hayool Git repository. There is no need to choose a live bank, AI provider, launch country, price, fundraising amount, marketplace take rate or employing entity to build M0.0 and the policy-disabled V1.0 foundation. Engineering can use synthetic fixtures and zero paid external-API budget until authorized. No automatic migration from this package into a protected repository is claimed. If a project repository already exists, its contents and governing decisions must be inspected before any code write; do not create a competing authoritative repository.

## Reserved decisions by activation gate

| ID / needed by | Decision for owner (with qualified review as appropriate) | Safe state until decision / evidence |
|---|---|---|
| ODR-001 V1.0 real internal use | Name Hayool contracting entity, actual accounting books/data controller, authorized signatories and finance reviewers. | Synthetic/internal test organization only; no real external contract or posting. |
| ODR-002 V1.1 partner | Choose pilot partner(s), allowed data, pilot commitments, confidentiality/support and permission to use outcome evidence. | Internal synthetic rehearsal only. |
| ODR-003 V1.2 live sourcing | Approve versioned IR exception policy if any, permitted real launch country/corridors and employer/work facts with counsel. | IR domestic-only product default; other countries simulated/disabled. No legal conclusion implied. |
| ODR-004 V1.4 managed mode | Choose employer/contractor/EOR/AOR/merchant and liability structure, responsible entities, worker protections, payout funding, insurance/IP and dispute obligations with counsel/accounting. | Managed mode disabled, no custody/escrow or employment claim. |
| ODR-005 V1.0 payment activation / V1.4 | Approve noncustodial payment/bank/tax/payroll providers per corridor, contract/DPA, fee/failure/settlement/liquidity obligations. | Adapters in sandbox; external money movement disabled. |
| ODR-006 before first external AI call (V1.5 broad gate) | Approve data classes, external model/processor contract/DPA, regions, cost ceilings, BYOK ownership and employment-AI impact review for any earlier meeting/talent use too. | AI-off/manual/deterministic product; shadow synthetic evaluation. |
| ODR-007 V1.6 commercial | Approve exact SaaS/modules/credits price, discounts, margin/business floor, refund/renewal, SLA exposure, support scope and cash/capital risk from sourced model. | No published offer, annual contract or SLA promise. |
| ODR-008 V1.6 marketing | Approve market/brand positioning, substantiated claims, first ICP/cohort and public statements; ensure evidence and jurisdiction scope. | Draft research and internal claims only. |
| ODR-009 V1.9 international | Prioritize named markets, hosting/data regions, controller/processor and cross-border transfer models, country pack publisher/support/legal reviewers. | Unverified country capabilities disabled; locale demos labeled. |
| ODR-010 V1.9–1.10 platform | Approve IP/open-source/core license, developer/partner contracts, marketplace merchant/payout/take rate/fees and liability allocation. | Private examples and tests; no public marketplace sale. |
| ODR-011 before autonomy escalation | Name human owners for security, finance, legal/compliance, on-call and release; approve any AE3+ merge or production automation and paid provider budget. | AE0/AE1 advisory/PR with human merge, external spend cap zero. |

Approval record must specify decision ID, legal entity, capability/country/corridor, options considered, qualified review, date/effective interval, signer, policy/version, tests/rollback and evidence. A decision on one corridor/provider does not approve all countries. The smallest blocking request at each gate is the row above plus concrete options based on then-current evidence; avoid hypothetical approval requests now. Final architecture can be used to begin engineering once the no-code phase is lifted, even though later commercial/legal activations remain held.
