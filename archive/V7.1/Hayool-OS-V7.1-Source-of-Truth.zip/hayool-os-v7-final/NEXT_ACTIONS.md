# NEXT_ACTIONS — priority queue

Updated 2026-09-25. Actions below are ordered by prerequisites and have concrete exit evidence. Document review is complete, and packaging must pass the final integrity script before delivery. Do not reinterpret a planned product action as complete. Only action 1–3 belong to the current no-code phase.

| Order | Action / owner role | Done when / dependency |
|---|---|
| 1 done | Documentation reviewer: audit REQ/ADR/source coverage, Iran/default policy, no feature deletion, release dependencies and consistency; repair blockers. | Two independent read-only PASS results on design digest in EVID-DOC-002. |
| 2 | Package owner: verify all 61 raw originals, generate hash manifest and archive; make package available durably. | Source/path/link/hash checks and ZIP/library save. |
| 3 | Owner: inspect only the reserved decisions needed for next phase. | To start coding, explicitly lift current no-code instruction and identify/authorize target repository and access; no need to settle later commercial/legal activations now. |
| 4 | Engineering (later coding phase): inspect supplied repo/default SHA/code/migrations/CI/rules/staging and existing decisions read-only; reconcile imports on branch. | Reality matrix and drift/owner-decision diff linked to SHA. Depends 3. |
| 5 | Engineering/Security: construct minimal M0.0 protected CI/ENG-RUN shadow Autopilot, no paid external provider by default. | Benign PR and seeded blocker traces; exact checks. Depends 4. |
| 6 | Independent reviewers: revalidate M0.1 against imported repo and run M0.2. | Review same exact SHA and close blockers, signed evidence. Depends 5. |
| 7 | Product/Engineering: implement thin V1.0 golden loop with tenant/finance/privacy/AI-off/accessibility and recovery invariants. | Real approved Hayool operation + independent ledger/tenant/restore proof; depends 6. |
| 8 | Product/Owner: recruit design partner and complete V1.1; choose live pack/provider/financial decisions only at the gates in OWNER_DECISIONS. | Independent journey evidence and signed activation policy; depends 7. |

At each action update PROJECT_STATE, REQ/ADR delta, evidence and risk. A failed hard test or unresolved qualified legal review blocks only dependent activation, and must not be declared passed because unrelated work continues. Never write to protected main directly, invent prices/law/provider availability or activate AI/system privileges from draft documents.
